import { useSelector } from "react-redux";

function AdminHome()
{

    const { name } = useSelector((state) => state.auth)

    return (
        <>
            <div class="register">
                <div class="container">
                    <h2>Welcome {name}</h2>
                </div>
            </div>
        </>
    )
}
export default AdminHome;