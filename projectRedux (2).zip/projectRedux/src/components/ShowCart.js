import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { userContext } from "../App";
import { useDispatch, useSelector } from "react-redux";

function ShowCart()
{

    const [cartdata, setcartdata] = useState([]);
    const { isLoggedIn, username } = useSelector((state) => state.auth)

    const navigate = useNavigate();
    const [billamt, setbillamt] = useState();

    async function fetchcart()
    {
        try
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/getcart?un=${username}`, { withCredentials: true })

            if (resp.data.statuscode === 1)
            {
                setcartdata(resp.data.cartinfo)
                sessionStorage.setItem("cartdata", JSON.stringify(resp.data.cartinfo));
            }
            else if (resp.data.statuscode === 0)
            {
                setcartdata([]);
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }
        catch (e)
        {
            toast.error("Error Occured " + e.message)
        }
    }


    useEffect(() =>
    {
        if (isLoggedIn === true)
        {
            fetchcart();
        }
    }, [isLoggedIn])

    // useEffect(()=>
    // {
    //     fetchcart();
    // },[])

    useEffect(() =>
    {
        // 0+76,0+765,0+456 ans will be 456(last one) in asynchronous function
        var gtotal = 0;
        for (var x = 0; x < cartdata.length; x++) // it is synchronous function
        {
            gtotal = gtotal + cartdata[x].TotalCost;
        }
        setbillamt(gtotal);

    }, [cartdata])

    useEffect(() =>
    {
        if (sessionStorage.getItem("userdata") === null)
        {
            navigate("/login")
            toast.error("please login to access the page")
        }
    }, [])



    async function ondel(id)
    {
        const userresp = window.confirm("Are you sure to Delete")

        if (userresp === true)
        {
            const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delproduct/${id}`)

            if (resp.data.statuscode === 1)
            {
                toast.success("Product Deleted Successfull")
                fetchcart();
            }
            else if (resp.data.statuscode === 0)
            {
                toast.error("Product not Deleted")
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }
    }

    function oncheckout()
    {
        sessionStorage.setItem("tbill", billamt);
        navigate("/checkout")
    }

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">ShowCart</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    {
                        cartdata.length > 0 ?
                            <>
                                <h2>List Of Products</h2><br />
                                <table className="table table-striped timetable_sub">
                                    <tbody>
                                        <tr>
                                            <th>Picture</th>
                                            <th>Name</th>
                                            <th>Rate</th>
                                            <th>Quantity</th>
                                            <th>Total Cost</th>
                                            <th>Delete</th>
                                        </tr>
                                    </tbody>
                                    {
                                        cartdata.map((item, index) =>
                                            <tr key={index}>
                                                <td><img src={`uploads/${item.Picture}`} height="75"></img></td>
                                                <td>{item.ProdName}</td>
                                                <td>{item.Rate}</td>
                                                <td>{item.Qty}</td>
                                                <td>{item.TotalCost}</td>
                                                <td><button className="btn btn-danger" onClick={() => ondel(item._id)}>Delete</button></td>
                                            </tr>
                                        )
                                    }
                                </table><br /><br />
                                <b>{cartdata.length} item(s) available in your cart</b><br /><br />
                                Rs.{billamt}/- is your total bill <br /><br />
                                <button name="btn" className="btn btn-primary" onClick={oncheckout}>Checkout</button>
                            </> : <h2>No Product Found</h2>
                    }
                </div>
            </div>

        </>
    )
}
export default ShowCart;