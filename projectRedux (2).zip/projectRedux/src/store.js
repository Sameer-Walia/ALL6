import { configureStore } from '@reduxjs/toolkit'
import authSlice from './reduxslices/authSlice'

const store = configureStore({
    reducer: {
        auth: authSlice
        // can store multiple reducers in this
    }
})

export default store


// authslice is a reducer in a store  and login , logout are its actions method
// store can have multiple reducer but there is only one store
// u can make multiple js files of reducers like authslice and store it in a store

// In Redux Toolkit:
// ✔️ authslice is the slice
// ✔️ authslice.reducer is the reducer
// ✔️ login and LogOut are action creators, not reducers
// ✔️ The functions inside reducers:{} (login, LogOut) are called case reducers

// authslice.reducer is the main reducer
// login() and LogOut() inside reducers:{} are “case reducers”
// login and LogOut (exported) are action creators

// The main reducer is:
// ✅ authslice.reducer
// authslice = A slice (collection of reducers + actions + initial state)