const multer = require('multer')
const fs = require('fs');  // to delete image from folder

const mystorage = multer.diskStorage({
  destination: (req, file, cb) =>
  {
    cb(null, 'public/uploads');//we will have to create folder in website where images will be saved
  },
  filename: (req, file, cb) =>
  {
    const picname = Date.now() + '-' + file.originalname;//1711956271167-oil3.webp , date in millinano-seconds
    //milliseconds will be added with original filename and name will be stored in picname constiable

    cb(null, picname);
  }
});
const upload = multer({ storage: mystorage })

module.exports = upload;