import axios from "axios";
import { useEffect, useRef, useState } from "react";
import { json, Link, useNavigate} from "react-router-dom";
import { toast } from "react-toastify";
import  useFetchCategories  from "../customhooks/useFetchCategories";

function ManageCategory() {

    const[catname , setcatname]=useState();
    const[catpic , setcatpic]=useState(null);
    const[msg , setmsg] = useState();
    const[catid , setcatid] = useState();
    const[picname , setpicname] = useState();
    const[edit , setedit] = useState(false);
    const navi = useNavigate()
    const fileInputRef = useRef(null);   // for cancel
    const [loading, setloading] = useState(false);


    const {catdata , setcatdata , loader , fetchallcat} = useFetchCategories();


    useEffect(() => {
        document.title = "Manage Category";
    }, []);


    async function addcat(e)
    {
        e.preventDefault()
        try
        {
            if(edit===false)   // because on updating , if we press enter product gets added ,not updated due to onsubmit of form
            {
                setloading(true);
                const fdata = new FormData();
                fdata.append("cname" , catname)
                if(catpic!=null)
                {
                    fdata.append("cpic" , catpic)
                }
    
                const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/savecategory` , fdata)
              
                if(resp.data.statuscode===1)
                {
                    toast.success("Category added successfully");
                    fetchallcat();
                    canceldb();
                }
                else  if(resp.data.statuscode===0)
                {
                    setmsg("Category not added");
                }
                else
                {
                    toast.error("Some Problem Occured")
                }
            }
           
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }


    async function ondelete(catid)
    {
        try
        {
            var pass = window.confirm("Are you sure to Delete")
            if(pass===true)
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delcat?id=${catid}`)
               
                if(resp.data.statuscode===1)
                {
                    toast.success(resp.data.msg)
                    fetchallcat();
                    canceldb();
                }
                else if(resp.data.statuscode===0)
                {
                    // alert(resp.data.msg)
                    toast.warn(resp.data.msg)
                }
                else
                {
                    alert("some problem occured")
                }
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }

    function onupdate(catitem)
    {
        setedit(true)
        setcatname(catitem.catname)
        setpicname(catitem.catpic)
        setcatid(catitem._id)
    }

    function canceldb()
    {
        setedit(false)
        setcatname("")
        setpicname("")
        setcatid("")
        setcatpic(null) // one same picture update at many places without updating , if done nothing picture will be updated so to stop this use null to clear the input type file
        // Clear the file input field
        if (fileInputRef.current) 
        {
            fileInputRef.current.value = ''; // Reset the value to clear the input
        }
    }

    async function updatedb()
    {    
        try
        {
            const formdata = new FormData();
            formdata.append("upname" , catname)  //either old name or new name

            if(catpic!==null)
            {
                formdata.append("uppic" , catpic)
            }
            formdata.append("oldpicname" , picname)
            formdata.append("cid" , catid)

            const resp = await axios.put(`${process.env.REACT_APP_APIURL}/api/updatecategory` , formdata)
           
            if(resp.data.statuscode===1)
            {
                toast.success("Category Updated Successfully")
                fetchallcat();
                canceldb();
            }
            else if(resp.data.statuscode===0)
            {
                toast.warn("Category not updated");  
                //  onimage it is not working
                // toast.success("Category Updated Successfully")
                // fetchallcat();
                // canceldb();
            }
            else
            {
                toast.error("some error occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }   
        
    }


    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Manage Category</li>
                    </ol>
                </div>
            </div>
            {/* pic will go in website folder */}
            {/* and pic-name will go in mondodb Database */}
            <div className="login">
                <div className="container">
                    <h2>Manage Category</h2>

                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">

                        <form name="form1" onSubmit={addcat}>   {/* remove onSumbit={addcat} because when we click on update and press enter it add category not changed it */}
                            <input type="text" name="catname" value={catname} placeholder="Category Name" required=" " onChange={(e)=>setcatname(e.target.value)}/><br/>
                            {
                                edit===true?
                                <>
                                    <img src={`uploads/${picname}`}  height="100"/>
                                    Choose new image, if required<br/><br/>
                                </>:null
                            }

                        <input type="file" accept="image/*" name="catpic" ref={fileInputRef} onChange={(e)=>setcatpic(e.target.files[0])}/>
                            {
                                edit===false?
                                <>
                                    {
                                        loading? 
                                        <div className="loader-container">
                                            <img src="images/loader.gif" alt="loader" className="loader" />
                                        </div>:<input type="submit" name="btn" value="Add" />
                                    }
                                </>:null
                            }
                            {
                                edit===true?
                                <>
                                    <input type="button" name="btn"  value="Update" onClick={updatedb}/>
                                    <input type="button" name="btn"  value="Cancel" onClick={canceldb}/>
                                </>:null
                            }
                            {msg}
                        </form>
                    </div>
                    
                </div>
            </div>


            <div className="login">
                <div className="container">
                    {
                        catdata.length>0?
                        <>
                            <h2>Added Categories</h2><br/>
                            <table className="table table-striped timetable_sub ">
                                <tbody >
                                    <tr >
                                        <th>Pic</th>
                                        <th>Category Name</th>
                                        <th>Update</th>
                                        <th>Delete</th>
                                    </tr>
                                </tbody>
                            {
                                catdata.map((item , index)=>
                                    <tr key={index} >
                                        <td><img src={`uploads/${item.catpic}`} height="75"/></td>
                                        <td >{item.catname}</td>
                                        <td><button className="btn btn-primary" onClick={()=>onupdate(item)}>Update</button></td>
                                        <td><button className="btn btn-danger" onClick={()=>ondelete(item._id)}>Delete</button></td>
                                    </tr>
                                )
                            }
                            </table><br/><br/>
                            {catdata.length} Products found
                        </>:<h2>No Category Found</h2>
                    }
                </div>
            </div><br/><br/>
        </>
        
    )
}
export default ManageCategory;