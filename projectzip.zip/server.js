const express = require('express')
const app = express()
const port = 9001
app.use(express.json());

const cors = require('cors')   // cross-origin resource sharing
app.use(cors({    // firstly request is allowed from any port
  origin:"http://localhost:3001", // your frontned  // now we make it strict by allowing it to accept requests from port no 3000 only
  credentials:true
}))


const multer = require('multer')
const fs = require('fs');  // to delete image from folder

let mystorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads');//we will have to create folder in website where images will be saved
  },
  filename: (req, file, cb) => {
    const picname = Date.now() + '-' + file.originalname;//1711956271167-oil3.webp , date in millinano-seconds
    //milliseconds will be added with original filename and name will be stored in picname constiable

    cb(null, picname);
  }
});
let upload = multer({ storage: mystorage })

const bcrypt = require('bcrypt');


require('dotenv').config()  // install dotenv package so that u can use ${process.env.SMTP_UNAME} here in backend , in front-end it is not require u can directly use like : const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/ContactUs` , data)

const nodemailer = require("nodemailer");
// to send emails to admin
// Create a test account or replace with real credentials.
const transporter = nodemailer.createTransport({
  host: "smtp.hostinger.com",
  port: 465,
  secure: true, // true for 465, false for other ports
  auth: {
    user: `${process.env.SMTP_UNAME}`,    
    pass: `${process.env.SMTP_PASS}`
  },
});

const {v4: uuidv4} = require('uuid')  // to set unique id after signup when gmail link is open before login

var jwt = require('jsonwebtoken');

const cookieParser = require("cookie-parser")
app.use(cookieParser());


function verifyjsontoken(req , res , next)
{
  // we need cookieParser here so that it can read cookie here , so install it
  let token = req.cookies.authToken
  if(token)
  {
    try
    {
      const decoded = jwt.verify(token , process.env.JWT_SKEY)
      console.log(decoded)
      req.utype=decoded.role
      req.id=decoded.id
      return next()
    }
    catch(e)
    {
      return res.send({statuscode:-5 , msg:"Invalid Token"})
    }
  } 
  
  const refreshtoken = req.cookies.refreshToken;
  if(!refreshtoken)
  {
    return res.send({statuscode:-5 , msg:"Session expired. Please log in again."})
  } 
  try
  {
    const decoded = jwt.verify(refreshtoken , process.env.JWT_REFRESH_SKEY)
    const newauthToken = jwt.sign({id:decoded.id , role:decoded.role} , process.env.JWT_SKEY , {expiresIn:"15m"})

    res.cookie("authToken" , newauthToken , {   
      httpOnly:true,
      secure: false,    
      sameSite:"lax",   
      maxAge: 15 * 60 * 1000,   
    });

    req.utype=decoded.role
    req.id=decoded.id
    return next()
  }
  catch(e)
  {
    return res.send({statuscode:-5 , msg:"Invalid refresh Token"})
  }
}

function verifyadmin(req , res , next)
{
  console.log(req.utype)
  if(req.utype==="admin")
  {
    return next();
  }
  else
  {
    return res.send({statuscode : -5 , msg:"Only Admin can access"})
  }
}


const mongoose = require('mongoose');
const { type } = require('os');
const { verify } = require('crypto');
mongoose.connect('mongodb://127.0.0.1:27017/projectdb').then(() => console.log('Connected to MongoDB'));


const SignupSchema = new mongoose.Schema({ pname: String, phone: String, username: { type: String, unique: true }, password: String , usertype:String , actstatus:Boolean , token:String}, { versionKey: false })
const SignupModel = mongoose.model("signup", SignupSchema, "signup");// internal name , schema_name , real collection name

app.post("/api/signup", async (req, res) => 
{
  try
  {
    const acttoken = uuidv4();
    console.log(acttoken)

    const encryp_pass = bcrypt.hashSync(req.body.pass , 10)

    const newrecord = new SignupModel({ pname: req.body.name, phone: req.body.phone, username: req.body.uname, password: encryp_pass , usertype:"normal" , actstatus:false , token:acttoken }) // this will create a temprory record into the model  , not in real connection

    const result = await newrecord.save();  // it will save the record into real collection
    // console.log(result)

    if (result) 
    {
      const mailOptions = {
        from: 'class@gtbinstitute.com', // transporter username email
        to: req.body.uname,             // user's email id
        subject: 'Activation Mail from SuperMarket.com',
        html: `Dear ${req.body.name}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${acttoken}'>Activate Account<a/>`
      };

      transporter.sendMail(mailOptions , (error , info)=>
      {
          if(error)
          {
            console.log(error);
            res.send({ statuscode: 2 })
          }
          else
          {
            console.log("Email sent: "+ info.response);
            res.send({ statuscode: 1})
          }
      });

    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.post("/api/resendmail", async (req, res) => {
  try 
  {
    const { uname } = req.body;

    const user = await SignupModel.findOne({ username: uname });
    console.log(user)
    if (user===null) 
    {
      res.send({ statuscode: 0, msg: "User not found with given email" });
    }
    else
    {
      // if user already get email and click on activate account then its actstatus is true but if he/she try to fetch email again then make actstatus:false like in 'if' part i made below

      // but if he doesnot get email 1 time then its actstatus is false by default and then user cannot get email again because actstatus is already false and cannot get updated in 'if' part , so due to this i have to make else part, where if part fails then else part run in which user get mail also on actstatus:false , 'if' part doesnot run beacuse actstatus cannot get updated 

      //  now user already login get email from if part and user who is logging first time but not get email yet can login from else part

      const updateresult = await SignupModel.updateOne({username: uname}, { $set: {actstatus:false}});
      if(updateresult.modifiedCount===1)
      {
        const mailOptions = {
          from: 'class@gtbinstitute.com',
          to: uname,
          subject: 'Activation Mail from SuperMarket.com',
          html: `Dear ${user.pname}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${user.token}'>Activate Account<a/>`
        };

        transporter.sendMail(mailOptions, (error, info) => 
        {
          if (error) 
          {
            console.log(error);
            res.send({ statuscode: 2});
          } 
          else 
          {
            console.log("Resend Email sent: " + info.response);
            res.send({ statuscode: 1 });
          }
        });
      }
      else
      {
        const mailOptions = {
          from: 'class@gtbinstitute.com',
          to: uname,
          subject: 'Activation Mail from SuperMarket.com',
          html: `Dear ${user.pname}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${user.token}'>Activate Account<a/>`
        };

        transporter.sendMail(mailOptions, (error, info) => 
        {
          if (error) 
          {
            console.log(error);
            res.send({ statuscode: 2});
          } 
          else 
          {
            console.log("Resend Email sent: " + info.response);
            res.send({ statuscode: 1 });
          }
        });
      }
    }
  } 
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
});


app.put("/api/activateuseraccount",async(req,res)=>
{
  try
  {
    const updateresult = await SignupModel.updateOne({token: req.body.code}, { $set: {actstatus:true}});
    if(updateresult.modifiedCount===1)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})


// before encryption

// app.post("/api/login", async (req, res) =>
// {
//   try
//   {

//     const result = await SignupModel.find({ username: req.body.uname, password: req.body.pass }).select("-password").select("-phone");
//     // result will become an array because find function return an array
//     console.log(result)
//     if (result.length === 0) 
//     {
//       res.send({ statuscode: 0 })
//     }
//     else 
//     {
//       res.send({ statuscode: 1, userdata: result[0] })
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1,errmsg:e.message})
//   }
// })


// after encryption

app.post("/api/login", async (req, res) => 
{
  try 
  {
    const result = await SignupModel.findOne({ username: req.body.uname }).select("-phone");
    console.log(result)
    if(result===null)
    {
      res.send({ statuscode: 0 })
    }
    else
    {
      if(bcrypt.compareSync(req.body.pass , result.password))
      {
        // .select("-phone"); = so phone:result.phone cannot be store in respdata
     
        const jsontoken = jwt.sign({id:result._id , role:result.usertype} , process.env.JWT_SKEY , {expiresIn:"15m"})
        const refreshjsontoken = jwt.sign({id:result._id , role:result.usertype} , process.env.JWT_REFRESH_SKEY , {expiresIn:"7d"})
        
        const respdata = {_id:result._id , pname:result.pname , phone:result.phone  , username:result.username , usertype:result.usertype , actstatus:result.actstatus  }

        res.cookie("authToken" , jsontoken , {   // authtoken is name of cookie and jsontoken is its value
          httpOnly:true,
          secure: false,    // when we launch the site , make is true
          sameSite:"lax",   // strict , lax , none 
          maxAge:15 * 60 * 1000,   // expiry time , time should be in milliseconds , 15 min
        });

        res.cookie("refreshToken" , refreshjsontoken , {   // authtoken is name of cookie and jsontoken is its value
          httpOnly:true,
          secure: false,    // when we launch the site , make is true
          sameSite:"lax",   // strict , lax , none 
          maxAge:7 * 24 * 60 * 60 * 1000,   // expiry time , time should be in milliseconds , 7 days
        });

        // strict = Cookie is only sent when the request comes from the *same site* (same domain + scheme). For example: http://localhost:3000 → http://localhost:3000 . It will NOT be sent to a different port like 3000 → 9000.

        // lax = Cookie is sent for top-level navigation GET requests (e.g., clicking a link from http://localhost:9000 to http://localhost:3000), like in our case .It is NOT sent for most other cross-site requests (like fetch, iframes, images).Also the default in modern browsers if SameSite is not set.

        // none = Cookie is sent with all requests, including cross-site (e.g., http://localhost:3000 ↔ http://localhost:9000).It Requires 'Secure=true' (must be HTTPS, except localhost is usually allowed in dev).

        res.send({ statuscode: 1 , userdata: respdata })

      }
      else
      {
        res.send({ statuscode: 0 })
      }
    }
  } 
  catch(e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
});

app.post("/api/logout",  (req, res) => 
{
  try 
  {
    res.clearCookie("authToken");
    res.clearCookie("refreshToken");
    res.send({statuscode:1})
  } 
  catch(e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
});


app.get("/api/searchuser", verifyjsontoken , verifyadmin , async (req, res) => 
{
  try
  {
    const result = await SignupModel.findOne({ username: req.query.un });
    console.log(result)
    if (result) 
    {
      res.send({ statuscode: 1, searchdata: result })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/getallusers", verifyjsontoken , verifyadmin ,async (req, res) => 
{
  try
  {
    const result = await SignupModel.find();
    // console.log(result)
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, usersdata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/fetchoneuser/:id", verifyjsontoken , verifyadmin ,async (req, res) => 
{
  try
  {
    const result = await SignupModel.findOne({_id:req.params.id});
    // console.log(result)
    if (result===null) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, oneuserdata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})
app.put("/api/updateoneuser", verifyjsontoken , verifyadmin ,async (req, res) => 
{
  try
  {
    const update = await SignupModel.updateOne({ _id:req.body.userid}, { $set: { pname:req.body.name , phone:req.body.phone , username:req.body.uname } })

    if (update.modifiedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.delete("/api/deluser/:uid",verifyjsontoken , verifyadmin , async (req, res) => 
{
  try
  {
    const result = await SignupModel.deleteOne({ _id: req.params.uid })  //{acknowledge:true , deletdCount:1 }
    // console.log(result)
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

// Before encryption

// app.put("/api/changepassword", async (req, res) => 
// {
//   try
//   {
//     const updatepass = await SignupModel.updateOne({ username: req.body.uname, password: req.body.currpass }, { $set: { password: req.body.newpass } })
//     console.log(updatepass)
//     if (updatepass.modifiedCount === 1) 
//     {
//       res.send({ statuscode: 1 })
//     }
//     else 
//     {
//       res.send({ statuscode: 0 })
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1,errmsg:e.message})
//   }
// })

// After encryption

app.put("/api/changepassword", verifyjsontoken ,async (req, res) => 
{
  try
  {
    const result = await SignupModel.findOne({ username: req.body.uname })
    console.log(result)
    if(result===null)
    {
      res.send({ statuscode: 0 })
    }
    else
    {
        if(bcrypt.compareSync(req.body.currpass , result.password))
        {
          const encryp_newpass = bcrypt.hashSync(req.body.newpass , 10)
          const updatepass = await SignupModel.updateOne({ username: req.body.uname }, { $set: { password:encryp_newpass } })
          if (updatepass.modifiedCount === 1) 
          {
            res.clearCookie("authToken");
            res.clearCookie("refreshToken");
            res.send({ statuscode: 1 })
          }
          else 
          {
            res.send({ statuscode: 0 })
          }
        }
        else
        {
          res.send({ statuscode: 0 })
        }
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

const CatSchema = new mongoose.Schema({ catname: { type: String, unique: true }, catpic: String }, { versionKey: false })
const CatModel = mongoose.model("category", CatSchema, "category");// internal name, schema_name, real collection_name

app.post("/api/savecategory", upload.single('cpic'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = "noimage.jpg"
    }
    else 
    {
      picturename = req.file.filename
    }
    const newrecord = new CatModel({ catname: req.body.cname, catpic: picturename })
    const result = await newrecord.save();
    if (result) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }

})

app.get("/api/getallcat", async (req, res) => 
{
  try
  {
    const result = await CatModel.find()
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, categorydata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.delete("/api/delcat", async (req, res) => 
{
  try
  {
    const result = await CatModel.deleteOne({ _id: req.query.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1, msg: "Category Deleted Successfully" })
    }
    else 
    {
      res.send({ statuscode: 0, msg: "Category not Deleted" })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})


app.put("/api/updatecategory", upload.single('uppic'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = req.body.oldpicname;//it will save current picname in this constiable
    }
    else 
    {
      picturename = req.file.filename;

      if (req.body.oldpicname !== "noimage.jpg") 
      {
        fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
      }

    }

    const updateresult = await CatModel.updateOne({ _id: req.body.cid }, { $set: { catname: req.body.upname, catpic: picturename } });

    if (updateresult.modifiedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.put("/api/updatesubcategory", upload.single('upsubpic'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = req.body.oldpicname;//it will save current picname in this constiable
    }
    else 
    {
      picturename = req.file.filename;

      if (req.body.oldpicname !== "noimage.jpg") 
      {
        fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
      }

    }

    const updateresult = await SubCatModel.updateOne({ _id: req.body.subcatid }, { $set: { subcatname: req.body.usubname, catid:req.body.cid ,subcatpic: picturename } });

    if (updateresult.modifiedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})


const SubCatSchema = new mongoose.Schema({ catid:{type: mongoose.Schema.Types.ObjectId, ref: 'category' } , subcatname: { type: String, unique: true }, subcatpic: String }, { versionKey: false })
const SubCatModel = mongoose.model("subcategory", SubCatSchema, "subcategory");   // internal name, schema_name, real collection_name

app.post("/api/addsubcategory", upload.single('picture'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = "noimage.jpg"
    }
    else 
    {
      picturename = req.file.filename
    }
    const newrecord = new SubCatModel({ catid:req.body.catid , subcatname: req.body.subcatname, subcatpic: picturename })
    const result = await newrecord.save();
    if (result) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }

})


const productSchema = new mongoose.Schema({ catid:{type: mongoose.Schema.Types.ObjectId, ref: 'category' }, subcatid:{type: mongoose.Schema.Types.ObjectId, ref: 'subcategory' }, Name: { type: String, unique: true }, Rate: Number, Discount: Number, Stock: Number, Description: String, Picture: String, ExtraPicture:[String] ,Addedon: Date }, { versionKey: false })
const productmodel = mongoose.model("product", productSchema, "product")

// app.post("/api/addproduct", upload.array('extraimages'), async (req, res) => // for multiple images from one input file
app.post("/api/addproduct", upload.fields([{name:"picture" , maxCount:1},{name:"extraimages"}]), async (req, res) => 
{
  try
  {

    const mainImage = req.files["picture"]? req.files["picture"][0].filename : "noimage.jpg"
    const extraImage = req.files["extraimages"]? req.files["extraimages"].map(file => file.filename): []; // Keep .map where you need a new array (extraImage).

    const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
    const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
    const currentDateIST = new Date(currentDateUTC.getTime()+ ISTOffset)  // convert to IST

    const newrecord = new productmodel({ catid: req.body.catid, subcatid:req.body.subcatid ,Name: req.body.pname, Rate: req.body.rate, Discount: req.body.dis, Stock: req.body.stock, Description: req.body.descp, Picture: mainImage, ExtraPicture:extraImage  ,Addedon:currentDateIST })

    const result = await newrecord.save()
    if (result) 
    {
      res.send({ statuscode: 1 })
    }
    else
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})



app.get("/api/fetchproductbycatidandsubcatid", async (req, res) => 
{
  try
  {
    const result = await productmodel.find({ catid: req.query.catid , subcatid: req.query.subcatid }).populate('catid').populate('subcatid')
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/fetchsubcatbycatid", async (req, res) => 
{
  try
  {
    const result = await SubCatModel.find({ catid: req.query.cid }).populate('catid');
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, subcatalldata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.delete("/api/delproduct", async (req, res) =>
{
  try
  {
    const result = await productmodel.deleteOne({ _id: req.query.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1, msg: "product deleted statuscodefully" })
    }
    else 
    {
      res.send({ statuscode: 0, msg: "product not deleted" })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.delete("/api/delsubcat", async (req, res) =>
{
  try
  {
    const result = await SubCatModel.deleteOne({ _id: req.query.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1, msg: "Subcategory deleted statuscodefully" })
    }
    else 
    {
      res.send({ statuscode: 0, msg: "Subcategory not deleted" })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.put("/api/updateproduct",  upload.fields([{name:"pic" , maxCount:1},{name:"extraimages"}]), async (req, res) => 
{
  try
  {
    // ---------- PRIMARY IMAGE ----------
    var picturename;
    if (!req.files["pic"]) 
    {
      picturename = req.body.oldpicname; // keep old one
    }
    else 
    {
      picturename = req.files["pic"][0].filename;  // new upload

      if (req.body.oldpicname !== "noimage.jpg") 
      {
        fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
      }
    
    }

    // ---------- EXTRA IMAGES ----------

    let extraImage;
    if (!req.files["extraimages"]) 
    {
      // if no new images selected → keep old ones
      extraImage = req.body.oldextrapicname ? req.body.oldextrapicname : [];;
    } 
    else 
    {
      // replace with new uploads
     extraImage = req.files["extraimages"]? req.files["extraimages"].map(file=> file.filename): []; // Keep .map where you need a new array (extraImage).

      // delete old extra images if provided
      if (req.body.oldextrapicname) 
      {
        req.body.oldextrapicname.forEach(img => {   // Keep .forEach where you just need side effects (delete files).
          if (img !== "noimage.jpg") {
            fs.unlinkSync(`public/uploads/${img}`);
          }
        });
      }
    }

    const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
    const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
    const currentDateIST = new Date(currentDateUTC.getTime()+ ISTOffset)  // convert to IST

    const updateresult = await productmodel.updateOne({ _id: req.body.productid }, { $set: { catid: req.body.catid, subcatid:req.body.subcatid ,Name: req.body.upname, Rate: req.body.uprate, Discount: req.body.updis, Stock: req.body.upstock, Description: req.body.updescp, Picture: picturename ,ExtraPicture:extraImage ,Addedon:currentDateIST} });

    if (updateresult.modifiedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/fetchprodbysubcatid", async (req, res) => 
{
  try
  {
    const result = await productmodel.find({ subcatid: req.query.subid }).populate('catid').populate('subcatid')
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/fetchproductbyid", async (req, res) => 
{
  try
  {
    const result = await productmodel.findOne({ _id: req.query.id })
    if (result===null) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, product: result})
      // res.send({ statuscode: 1, product: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/fetchproductbyid1", async (req, res) => 
{
  try
  {
    const result = await productmodel.find({ _id: req.query.id })
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, product: result})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})


const cartSchema = new mongoose.Schema({pid:String , Picture: String, ProdName: String, Rate: Number, Qty: Number, TotalCost: Number, Username: String }, { versionKey: false })
const CartModel = mongoose.model("cart", cartSchema, "cart");// internal name, schema_name, real collection_name

app.post("/api/addtocart", async (req, res) => 
{
  try
  {
    const newrecord = new CartModel({ pid:req.body.pid ,Picture: req.body.picture, ProdName: req.body.pname, Rate: req.body.rate, Qty: req.body.qty, TotalCost: req.body.tc, Username: req.body.username })

    const result = await newrecord.save();

    if (result) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/getcart", verifyjsontoken , async (req, res) => 
{
  try 
  {
    const result = await CartModel.find({ Username: req.query.un })
    if (result.length === 0)
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, cartinfo: result })
    }
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.delete("/api/delproduct/:id", async (req, res) => 
{
  try
  {
    const result = await CartModel.deleteOne({ _id: req.params.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

const orderSchema = new mongoose.Schema({address:Object,billamt:Number,username:String,OrderDate:Date,PayMode:String,CardDetails:Object,OrderProducts:[Object],status:String},{versionKey:false})

const OrderModel = mongoose.model("finalorder",orderSchema,"finalorder");
app.post("/api/saveorder",async(req,res)=>
{
  try
  {

    const newrecord = new OrderModel({address:req.body.address,billamt:req.body.tbill,username:req.body.uname,OrderDate:new Date(),PayMode:req.body.pmode,CardDetails:req.body.carddetails,OrderProducts:req.body.cartinfo,status:"Payment received, processing"}) 

    const result = await newrecord.save();

    if(result)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }  
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  } 
})

app.put("/api/updatestock",async(req,res)=>
{
  try
  {
    const cartdata = req.body.cartinfo;
    for(var x=0;x<cartdata.length;x++)
    {
      var updateresult = await productmodel.updateOne({_id: cartdata[x].pid}, {$inc:{"Stock":-cartdata[x].Qty}});
      // In MongoDB, $inc is an update operator that increments or decrements a numeric field by a given value.
    }
    if(updateresult.modifiedCount===1)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }
  }
  catch(e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  } 
})

app.delete("/api/deletecart",async(req,res)=>
{
  try
  {
    const result = await CartModel.deleteMany({Username:req.query.un})//{ acknowledged: true, deletedCount: ... }
    if(result.deletedCount>=1)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }    
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  } 
})

app.get("/api/getorderid",async(req,res)=>
{
  try
  {
    const name = req.query.name;
    const result = await OrderModel.findOne({username:req.query.un}).sort({"OrderDate":-1});
    console.log(result)
    if(result)
    {
      // on email to show multiple product details 
      const productList = result.OrderProducts.map(item => `
        <li>
          ${item.ProdName} (Qty: ${item.Qty}) - ₹${item.TotalCost}
        </li>
      `).join("");

      const mailOptions = {
        from: 'class@gtbinstitute.com',
        to: req.query.un,
        subject: 'Order Details from SuperMarket.com',
        html: `
          Dear ${name},<br/><br/>
          Thanks for the Order.<br/><br/>
          <b>Your Order Details are:</b><br/><br/>
          <b>Order Number :- </b>${result._id}<br/>
          <b>Products :- </b> :- <ul>${productList}</ul>
          <b>Bill :- </b> ₹${result.billamt}<br/>
          <b>Payment Mode :- </b> ${result.PayMode}<br/>
          <b>Order Date :- </b> ${new Date(result.OrderDate).toLocaleString()}<br/>
          <b>Address :- </b> ${result.address.house}, ${result.address.area}, ${result.address.city}, ${result.address.state} - ${result.address.pincode}<br/>
          <b>Status :- </b> ${result.status}
        `
      };

      transporter.sendMail(mailOptions, (error, info) => 
      {
        if (error) 
        {
          console.log(error);
          res.send({ statuscode: 2});
        } 
        else 
        {
          console.log("Resend Email sent: " + info.response);
          res.send({ statuscode: 1 , orderdata:result});
        }
      });
    }
    else
    {
      res.send({statuscode:0})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/getallorders",async(req,res)=>
{
  try
  {
    const result = await OrderModel.find().sort({"OrderDate":-1})
    if(result.length===0)
    {
      res.send({statuscode:0})
    }
    else
    {
      res.send({statuscode:1,ordersdata:result})
    }    
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/getallordersbydate", verifyjsontoken , verifyadmin, async(req,res)=>
{
  try
  {
    const inputDate = req.query.odate   // Eg = "2025-04-22"
    const paymode = req.query.pmode
    console.log(paymode) 
    const status = req.query.status
    console.log(status) 

    // Convert the input date to IST timezone start & end of day
    const startOfDay = new Date(new Date(inputDate).setHours(0, 0, 0, 0));
    const endOfDay = new Date(new Date(inputDate).setHours(23, 59, 59, 999));

    // $gte = greater than equal to  and   $lte = less than equal to

    var result;

    if(paymode===undefined && status===undefined)
    {
      result = await OrderModel.find({OrderDate: { $gte: startOfDay , $lte: endOfDay }}).sort({"OrderDate":-1})
    }
    else if(paymode===undefined)
    {
      result = await OrderModel.find({OrderDate: { $gte: startOfDay , $lte: endOfDay }, status:status}).sort({"OrderDate":-1})
    }
    else if(status===undefined)
    {
      result = await OrderModel.find({OrderDate: { $gte: startOfDay , $lte: endOfDay }, PayMode:paymode}).sort({"OrderDate":-1})
    }
    else
    {
      result = await OrderModel.find({OrderDate: { $gte: startOfDay , $lte: endOfDay } , PayMode:paymode  , status:status}).sort({"OrderDate":-1})
    } 
    if(result.length===0)
    {
      res.send({statuscode:0})
    }
    else
    {
      res.send({statuscode:1,ordersdata:result})
    }    
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})


app.delete("/api/delorder/:id", async (req, res) => 
{
  try
  {
    const result = await OrderModel.deleteOne({ _id: req.params.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.put("/api/updatestatus",async(req,res)=>
{
  try
  {
    const updateresult = await OrderModel.updateOne({_id: req.body.orderid}, { $set: {status:req.body.newst}});

    if(updateresult.modifiedCount===1)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/getorderproducts",async(req,res)=>
{
  try
  {
    const result = await OrderModel.findOne({_id:req.query.orderno});
    if(result===null)
    {
      res.send({statuscode:0})
    }
    else
    {
      res.send({statuscode:1,items:result.OrderProducts})
    }  
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/getuserorders", verifyjsontoken ,async(req,res)=>
{
  try
  {
    const result = await OrderModel.find({username:req.query.un}).sort({"OrderDate":-1})

    if(result.length===0)
    {
      res.send({statuscode:0})
    }
    else
    {
      res.send({statuscode:1,ordersdata:result})
    }    
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/searchproducts",async(req,res)=>
// rest function in header
{
  try
  {
    const searchtext = req.query.q;
    const result = await productmodel.find({Name: { $regex: '.*' + searchtext ,$options:'i' }})
    //result will become an array because find function returns an array
    if(result.length===0)
    {
      res.send({statuscode:0})
    }
    else
    {
      res.send({statuscode:1,proddata:result})
    }    
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/fetchlatestprods", async (req, res) => 
{
  try
  {
    const result = await productmodel.find().sort({"Addedon":-1}).limit(6)
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.get("/api/SearchOrderId", async (req, res) => 
{
  try
  {
    const result = await OrderModel.find({_id:req.query.un})
    //result will become an array because find function returns an array
    if (result.length===1) 
    {
      res.send({ statuscode: 1, proddata: result })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.post("/api/ContactUs" , async(req , res)=>
{
  try
  {

    // verify capctha
    const secretKey = "6LfERsgrAAAAAOCiGEhPE5XOgemCKahJfqdWUw5v"; // backend only
    const captchaURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${req.body.captchaToken}`;

    const captchaResponse = await fetch(captchaURL, {method: "POST"});
    const captchaData = await captchaResponse.json();
    console.log(captchaData)
    if (captchaData.success===false) 
    {
      return res.json({ success: 0, msg: "Captcha verification failed" });
    }

    //  If captcha passes → send email

    const mailOptions = {
      from: 'class@gtbinstitute.com', // transporter username email
      to: 'sameerwalia13@gmail.com',  // any email id of admin where u want to send email
      replyTo: req.body.email,
      subject: 'Message from website - Contact Us Page',
      html: `<b>Name:- </b>${req.body.uname}<br/><b>Phone:- </b>${req.body.phone}<br/><b>Email:- </b>${req.body.email}<br/><b>Message:- </b>${req.body.message}`
    };

    transporter.sendMail(mailOptions , (error , info)=>
    {
        if(error)
        {
          console.log(error);
          res.send({ statuscode: 0 })
        }
        else
        {
          console.log("Email sent: "+ info.response);
          res.send({ statuscode: 1 })
        }
    });

  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

// app.get("/api/getalladmincontact" , async(req , res)=>
// {
//   try
//   {
//     const result = await contactModel.find().sort({"ContactOn":-1})
//     {
//       if(result.length===0)
//       {
//         res.send({statuscode:0})
//       }
//       else
//       {
//         res.send({statuscode:1 , contactdata:result})
//       }  
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1})
//     console.log(e.message)
//   }
// })

// app.delete("/api/delcontact/:id" , async(req , res)=>
// {
//   try
//   {
//     const result = await contactModel.deleteOne({_id:req.params.id})
//     {
//       if(result.deletedCount===1)
//       {
//         res.send({statuscode:1})
//       }
//       else
//       {
//         res.send({statuscode:0})
//       }  
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1})
//     console.log(e.message)
//   }
// })

const ResetPassSechema = new mongoose.Schema({ username:String , exptime:Date , token:String} , { versionKey: false })
const restPassModel = mongoose.model("resetpass", ResetPassSechema, "resetpass");// internal name, schema_name, real collection_name

app.get("/api/forgotpassword", async (req, res) => 
{
  try 
  {
    const result = await SignupModel.findOne({ username: req.query.un })
    console.log(result)
    if(result===null)
    {
      res.send({ statuscode: 3 })
    }
    else
    {
      const passtoken = uuidv4();

      const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
      const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
      const fifteenminOffset = 15 * 60 * 1000; // IST offset in milliseconds (15 minutes)
      const expiretime = new Date(currentDateUTC.getTime()+ ISTOffset +  fifteenminOffset )  // add 15 min more

      const newrecord = new restPassModel({username:req.query.un , exptime:expiretime , token:passtoken })
      const result2 = newrecord.save()
      if(result2)
      {
        const mailOptions = {
          from: 'class@gtbinstitute.com', // transporter username email
          to: req.query.un,             // user's email id
          subject: 'Reset Password Mail from SuperMarket.com',
          html: `Dear ${result.pname}<br/><br/>Click on the Following Link to Reset your Password :-.<br/><br/><a href='http://localhost:3000/resetpassword?code=${passtoken}'>Reset Password<a/>`
        };

        transporter.sendMail(mailOptions , (error , info)=>
        {
            if(error)
            {
              console.log(error);
              res.send({ statuscode: 2 })
            }
            else
            {
              console.log("Email sent: "+ info.response);
              res.send({ statuscode: 1})
            }
        });

      }
      else
      {
        res.send({statuscode:0})
      }
       
    }
    
  } 
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
});

app.get("/api/checktoken" , async(req , res)=>
{
    const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
    const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
    const currtime = new Date(currentDateUTC.getTime()+ ISTOffset ) 
    console.log(currtime)

  try
  {
    const result = await restPassModel.findOne({token:req.query.token})
    console.log(result)
    {
      if(result===null)
      {
        res.send({statuscode:0})
      }
      else
      {
        if(currtime<result.exptime)   // 5:20 < 5:30
        {
          res.send({statuscode:1})
        }
        else
        {
          // delete Token after it get expired
          const result2 = await restPassModel.deleteOne({ token: req.query.token })  
          if (result2.deletedCount === 1) 
          {
            res.send({ statuscode:0 })
          }
          else 
          {
            res.send({ statuscode:2 })
          }
        }
      }  
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})


app.put("/api/resetpassword", async (req, res) => 
{
  try
  {
    const result = await restPassModel.findOne({ token: req.body.token })
    console.log(result)
    if(result===null)
    {
      res.send({ statuscode: 0 })
    }
    else
    {
      const encryp_newpass = bcrypt.hashSync(req.body.newpass , 10)
      const updatepass = await SignupModel.updateOne({ username: result.username }, { $set: { password:encryp_newpass } })
      if (updatepass.modifiedCount === 1) 
      {
        res.send({ statuscode: 1 })
      }
      else 
      {
        res.send({ statuscode: 0 })
      }
       
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})



app.listen(port, () => {
  console.log(`Server is running on port ${port}`)
})