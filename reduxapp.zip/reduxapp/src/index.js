import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { configureStore } from '@reduxjs/toolkit';
import { Provider } from 'react-redux';
import userSlice from './userReducer';

const root = ReactDOM.createRoot(document.getElementById('root'));

const mystore = configureStore({
  reducer: userSlice
})

root.render(
  <Provider store={mystore}>
    <App />
  </Provider>
);


reportWebVitals();
