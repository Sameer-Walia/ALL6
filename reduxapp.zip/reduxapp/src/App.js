import { useDispatch, useSelector } from 'react-redux';
import './App.css';
import { fetchName, UpdateAge, UpdateGender, UpdateName } from './userReducer';

function App()
{
  const dispatch = useDispatch()

  const { name, age, gender } = useSelector((state) =>
  {
    return state
  })

  const editname = () =>
  {
    // dispatch(UpdateName("Radhika"))
    dispatch(fetchName())
  }

  const editage = (newage) =>
  {
    dispatch(UpdateAge(newage))
  }

  const editgender = () =>
  {
    dispatch(UpdateGender("Female"))
  }

  return (
    <div className="App">
      <header className="App-header">
        Name is {name}<br />
        Age is {age}<br />
        Gender is {gender}<br /><br />
        <button onClick={editname}>Change Name</button><br />
        <button onClick={() => editage(22)}>Change Age</button><br />
        <button onClick={editgender}>Change Gender</button>
      </header>
    </div>
  );
}

export default App;





// const editname = () =>
// {
//   dispatch({ type: "UpdateName", payload: "Ramesh Sharma" })
// }

// const editage = (newage) =>
// {
//   dispatch({ type: "UpdateAge", updatedVal: newage })
// }

// const editgender = () =>
// {
//   dispatch({ type: "UpdateGender", updatedVal: "Female" })
// }