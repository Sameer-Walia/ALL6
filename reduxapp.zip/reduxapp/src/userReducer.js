import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const fetchName = createAsyncThunk(
    'fetchname',  // internal name
    async (arg, thunkAPI) =>
    {
        try
        {
            const response = await fetch('https://jsonplaceholder.typicode.com/users');

            if (!response.ok)
            {
                // The response.ok property is true if the HTTP status code is between 200–299 (success).
                // If the request fails (e.g., 404, 500, etc.), response.ok becomes false.
                return thunkAPI.rejectWithValue('Failed to fetch data');
            }

            const data = await response.json();
            return data[0].name;
        }
        catch (error)
        {
            return thunkAPI.rejectWithValue(error.message)
        }

    }
);

const istate = { name: "Ramesh", age: 20, gender: "Male" }

const userSlice = createSlice({
    name: "user",
    initialState: istate,
    reducers: {
        UpdateName(state, action)
        {
            state.name = action.payload;
        },
        UpdateAge(state, action)
        {
            state.age = action.payload
        },
        UpdateGender(state, action)
        {
            state.gender = action.payload
        }
    },
    extraReducers: (builder) =>
    {
        builder
            .addCase(fetchName.pending, (state) =>
            {
                state.name = 'Loading......';
            })
            .addCase(fetchName.fulfilled, (state, action) =>
            {
                state.name = action.payload;
            })
            .addCase(fetchName.rejected, (state) =>
            {
                state.name = 'Failed to fetch Data';
            });
    },
})

export const { UpdateName, UpdateAge, UpdateGender } = userSlice.actions;
export default userSlice.reducer





// import { createReducer } from "@reduxjs/toolkit";

// const istate = { name: "Ramesh", age: 20, gender: "Male" }

// export default createReducer(istate, (builder) =>
// {
//     builder.addCase('UpdateName', (state, action) =>
//     {
//         state.name = action.payload;
//     })
//     builder.addCase('UpdateAge', (state, action) =>
//     {
//         state.age = action.updatedVal
//     })
//     builder.addCase('UpdateGender', (state, action) =>
//     {
//         state.gender = action.updatedVal
//     })
// })