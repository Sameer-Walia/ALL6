const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({ catid:{type: mongoose.Schema.Types.ObjectId, ref: 'category' }, subcatid:{type: mongoose.Schema.Types.ObjectId, ref: 'subcategory' }, Name: { type: String, unique: true }, Rate: Number, Discount: Number, Stock: Number, Description: String, Picture: String, ExtraPicture:[String] ,Addedon: Date }, { versionKey: false })

module.exports = mongoose.model("product", productSchema, "product")