const mongoose = require('mongoose');

const cartSchema = new mongoose.Schema({pid:String , Picture: String, ProdName: String, Rate: Number, Qty: Number, TotalCost: Number, Username: String }, { versionKey: false })

module.exports = mongoose.model("cart", cartSchema, "cart");