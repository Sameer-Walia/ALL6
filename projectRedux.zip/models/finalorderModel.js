const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({address:Object,billamt:Number,username:String,OrderDate:Date,PayMode:String,CardDetails:Object,OrderProducts:[Object],status:String},{versionKey:false})

module.exports = mongoose.model("finalorder",orderSchema,"finalorder");