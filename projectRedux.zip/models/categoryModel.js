const mongoose = require('mongoose');

const CatSchema = new mongoose.Schema({ 
        catname: { 
            type: String, 
            unique: true 
        }, 
        catpic: { 
            type: String, 
        }
    }, { versionKey: false })

module.exports = mongoose.model("category", CatSchema, "category");
