const mongoose = require('mongoose');

const SignupSchema = new mongoose.Schema({ 

    pname:  { 
        type: String, 
        required : true 
    }, 

    phone: { 
        type: String,
         required : true
    }, 
    
    username: { 
        type: String, 
        unique: true , 
        required : true
    }, 

    password: { 
        type: String, 
        required : true 
    }, 

    usertype:{ 
        type: String, 
        required : true 
    }, 

    actstatus:{ 
        type: Boolean, 
        required : true 
    }, 
    
    token:{ 
        type: String, 
        required : true 
    }, 

}, { versionKey: false })

module.exports = mongoose.model("signup", SignupSchema, "signup");// internal name , schema_name , real collection name