import Header from "./components/Header";
import Footer from "./components/Footer";
import Siteroutes from "./components/Siteroutes";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { createContext, useEffect, useState } from "react";
import AdminHeader from "./components/AdminHeader";
import Cookies from "universal-cookie";
import { useNavigate } from "react-router-dom";

const userContext = createContext(null)

function App()
{
  const [udata, setudata] = useState(null);
  const usercokkie = new Cookies()
  const navi = useNavigate()

  useEffect(() =>
  {
    if (sessionStorage.getItem("userdata") !== null)
    {
      setudata(JSON.parse(sessionStorage.getItem("userdata")));
    }
  }, [])

  useEffect(() =>
  {
    const cookieUser = usercokkie.get("staysignin"); // universal-cookie auto-parses JSON , no need to do JSON.parse
    if (cookieUser)
    {
      setudata(cookieUser);
      sessionStorage.setItem("userdata", JSON.stringify(cookieUser));
    }
  }, []);


  return (
    <>
      <userContext.Provider value={{ udata, setudata }}>
        {
          udata === null ? <Header />
            : udata.usertype === "admin" ? <AdminHeader /> :
              <Header />
        }
        <Siteroutes />
        <Footer />
      </userContext.Provider>
      <ToastContainer theme="colored" />
    </>
  );
}
export default App;
export { userContext }