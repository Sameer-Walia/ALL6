import { useContext, useEffect } from "react";
import { userContext } from "../App";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function AdminHome()
{

    const { udata } = useContext(userContext);
    const navi = useNavigate()

    return (
        <>
            <div class="register">
                <div class="container">
                    <h2>Welcome {udata?.pname}</h2>
                </div>
            </div>
        </>
    )
}
export default AdminHome;