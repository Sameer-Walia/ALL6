import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";

function SearchProducts() {
    const [params] = useSearchParams();
    const sterm = params.get("s");

    const [prodsdata,setprodsdata]=useState([]);

    useEffect(()=>
    {
        if(sterm!=="")
        {
            searchprods();
        }
    },[sterm])
    
    async function searchprods()
    {
        try
        {
            const resp =  await axios.get(`${process.env.REACT_APP_APIURL}/api/searchproducts?q=${sterm}`)
           
            if(resp.data.statuscode===1)
            {
                setprodsdata(resp.data.proddata)
            }
            else if(resp.data.statuscode===0)
            {
                setprodsdata([]);
            }
            else
            {
                toast.warn("Some error occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }
    return (
        <>
            <div className="login">
                <div className="container">
                    {
                        prodsdata.length>0?
                        <>
                            {
                                prodsdata.map((item, index) =>
                                        <div className="col-md-4 top_brand_left" key={index}>
                                            <div className="hover14 column">
                                                <div className="agile_top_brand_left_grid">
                                                    <div className="agile_top_brand_left_grid1">
                                                        <figure>
                                                            <div className="snipcart-item block" >
                                                                <div className="snipcart-thumb">
                                                                    <Link to={`/details?pid=${item._id}`}>
                                                                        <img title=" " alt=" " src={`uploads/${item.Picture}`} height='125'/>
                                                                        <p>{item.Name}</p>
                                                                    </Link>
                                                                </div>
                                                            </div>
                                                        </figure>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                )
                            }
                        </>:<h2>No products found</h2>
                    }


                </div>
            </div>
        </>
    )
}
export default SearchProducts;