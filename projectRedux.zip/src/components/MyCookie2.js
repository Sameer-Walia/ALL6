import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Cookies from 'universal-cookie'

function MyCookie2()
{
    const cookies = new Cookies();

    const translations = {
        en: "User Preferences",
        hi: "उपयोगकर्ता वरीयताएँ",
        fr: "Préférences Utilisateur",
    };

    const [theme, setTheme] = useState('light')
    const [language, setLanguage] = useState('en')

    // const [theme, setTheme] = useState(cookies.get("theme"))
    // const [language, setLanguage] = useState(cookies.get("language"))

    useEffect(() =>
    {
        const savedTheme = cookies.get("theme");
        const savedLanguage = cookies.get("language");
        if (savedTheme) 
        {
            setTheme(savedTheme);
        }
        if (savedLanguage) 
        {
            setLanguage(savedLanguage);
        }
    }, []);

    useEffect(() =>   // Creates cookies with default values on first load when there is not cookie set
    {
        cookies.set("theme", theme, { path: "/", maxAge: 7 * 24 * 60 * 60 }); // 7 days
        cookies.set("language", language, { path: "/", maxAge: 7 * 24 * 60 * 60 });
    }, [theme, language]);

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Cookie Page</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    <div
                        style={{
                            background: theme === "dark" ? "#333" : "#fff",
                            color: theme === "dark" ? "#fff" : "#000",
                            padding: "20px",
                            borderRadius: "8px",
                        }}
                    >
                        <h2 style={{ color: theme === "dark" ? "#fff" : "#000" }}>
                            {translations[language] || "User Preferences"}
                        </h2>

                        <div>
                            <label>Theme:&nbsp;</label>
                            <select
                                value={theme}
                                onChange={(e) => setTheme(e.target.value)}
                                style={{
                                    background: theme === "dark" ? "#444" : "#fff",
                                    color: theme === "dark" ? "#fff" : "#000",
                                    padding: "5px",
                                    borderRadius: "5px",
                                    border: "1px solid #ccc",
                                }}
                            >
                                <option value="light">🌞 Light</option>
                                <option value="dark">🌙 Dark</option>
                            </select>
                        </div>


                        <div>
                            <label>Language:&nbsp;</label>
                            <select
                                value={language}
                                onChange={(e) => setLanguage(e.target.value)}
                                style={{
                                    background: theme === "dark" ? "#444" : "#fff",
                                    color: theme === "dark" ? "#fff" : "#000",
                                    padding: "5px",
                                    borderRadius: "5px",
                                    border: "1px solid #ccc",
                                }}
                            >
                                <option value="en">English</option>
                                <option value="hi">Hindi</option>
                                <option value="fr">French</option>
                            </select>
                        </div>

                        <p>
                            Current Settings : {theme} theme , {language.toUpperCase()} language
                        </p>
                    </div>
                </div>
            </div><br /><br />

        </>
    )
}

export default MyCookie2
