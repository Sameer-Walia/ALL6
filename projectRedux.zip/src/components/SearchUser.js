import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";


function SearchUser() 
{

    const[uname , setuname]=useState();
    const[msg , setmsg] = useState();
    const[flag , setflag] = useState(false);
    const[udata , setudata] = useState(false);

    const navi = useNavigate();

    async function onlogin(e)
    {
        e.preventDefault()
        try
        {
            // const resp = await axios.get("${process.env.REACT_APP_APIURL}/api/searchuser?un="+uname)

            // const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/searchuser?un=${uname}` , {headers :{authorization:sessionStorage.getItem("jsontoken")}});

            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/searchuser?un=${uname}` , {withCredentials:true});

            if(resp.data.statuscode===0)
            {
                toast.warning("No User Found");
                setflag(false)
            }
            else if(resp.data.statuscode===1)
            {
                setmsg("")
                setflag(true)
                setudata(resp.data.searchdata)
            }
            else if(resp.data.statuscode===-5)
            {
                toast.error(resp.data.msg)
                navi("/login")
            }
            else
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }

    // async function onlogin(e)
    // {
    //     e.preventDefault()
    //     try
    //     {
    //         const apiresp = await fetch(`${process.env.REACT_APP_APIURL}/api/searchuser?un=${uname}`, {credentials: "include" })
            
    //         if(apiresp.ok)
    //         {
    //             const resp = await apiresp.json()
    //             if(resp.statuscode===0)
    //             {
    //                 toast.warning("No User Found");
    //                 setflag(false)
    //             }
    //             else if(resp.statuscode===1)
    //             {
    //                 setmsg("")
    //                 setflag(true)
    //                 setudata(resp.searchdata)
    //             }
    //             else if(resp.statuscode===-5)
    //             {
    //                 toast.error(resp.msg)
    //                 navi("/login")
    //             }
    //             else
    //             {
    //                 toast.warn("Some Problem Occured")
    //             }
    //         }
    //     }
    //     catch(e)
    //     {
    //         toast.error("Error Occured " + e.message)
    //     }
    // }




    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Search User</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    <h2>Search User</h2>

                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
                        <form name="form1" onSubmit={onlogin}>
                            <input type="email" name="un" placeholder="Email Address(username)" required=" " onChange={(e)=>setuname(e.target.value)}/>
                            <input type="submit" name="btn" value="Search" /><br/><br/>
                            {msg}
                        </form>
                        {
                            flag===true?
                            <>
                                <b>Name:-</b>{udata.pname}<br/>
                                <b>Phone:-</b>{udata.phone}<br/>
                                <b>Email:-</b>{udata.username}<br/>
                            </>:null
                        }
                    </div>
                    <h4>For New People</h4>
                  
                    <p><Link to="/signup">Register Here</Link> (Or) go back to <Link to="/">Home</Link><span className="glyphicon glyphicon-menu-right" aria-hidden="true"></span></p>
                </div>
            </div>

        </>
    )
}
export default SearchUser;