import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { userContext } from "../App";


function AdminContactUs() {

   
    const [contactdata, setcontactdata] = useState([]);
    

    const navi = useNavigate();

    async function fetchcontact() 
    {
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/getalladmincontact`)
            if (resp.data.statuscode === 0) 
            {
                setcontactdata([]);
            }
            else if (resp.data.statuscode === 1) 
            {
                setcontactdata(resp.data.contactdata) 
            }
            else 
            {
                toast.error("Some Problem Occured")
            }
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
    }

    useEffect(()=>
    {
        fetchcontact();
    },[])


    useEffect(() => {
        if (sessionStorage.getItem("userdata") === null) 
        {
            navi("/login")
            toast.error("please login to access the page")
        }
        else
        {
            const uinfo = JSON.parse(sessionStorage.getItem("userdata"))
            if(uinfo.usertype!=="admin")
            {
                navi("/login")
                toast.error("please login to access the admin page")
            }
        }
    }, [])

    async function oncontactdel(id)
    {
        const userresp = window.confirm("Are you sure to delete")
        if(userresp===true)
        {
            try
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delcontact/${id}`)
            
                if(resp.data.statuscode===1)
                {
                    toast.success("User Deleted Successfull")
                    fetchcontact();
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("User not Deleted")
                }
                else
                {
                    toast.error("Some Problem Occured")
                }
            }
            catch (e) 
            {
                toast.error("Error Occured " + e.message)
            }
        }  
    }



    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/adminhome"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Contact-Us</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    {
                        contactdata.length>0?
                        <>
                            <h2>List Of Contact-Us</h2><br/>
                            <table className="table table-striped timetable_sub">
                                <tbody>
                                    <tr>
                                        <th>Username</th>
                                        <th>Name</th>
                                        <th>Email-Id</th>
                                        <th>Message</th>
                                        <th>Time</th>
                                        <th>Delete</th>
                                    </tr>
                                 </tbody>
                            {
                                contactdata.map((item , index)=>
                                    <tr key={index}>
                                        <td>{item.username}</td>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.message}</td>
                                        <td>{item.ContactOn}</td>
                                        <td><button className="btn btn-danger" onClick={()=>oncontactdel(item._id)}>Delete</button></td>
                                    </tr>
                                )
                            }
                            </table><br/><br/>
                            {contactdata.length} Contact found
                        </>:<h2>Contact On Email</h2>
                    }
                </div>
            </div>

        </>
    )
}
export default AdminContactUs;