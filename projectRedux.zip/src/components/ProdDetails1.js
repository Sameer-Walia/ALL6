import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";
import { userContext } from "../App";

function ProdDetails() {
    const [prod, setprod] = useState([]);
    const [params] = useSearchParams();
    const prdid = params.get("pid")

    const [stock, setstock] = useState([])
    const [qty, setqty] = useState()
    const [tc, settc] = useState()
    const navigate = useNavigate()

    const [remcost, setremcost] = useState();

    const { udata } = useContext(userContext)

    useEffect(() => {
        fetchproductbyid();
    }, [prdid])

    useEffect(() => {
        if(prod.length>0)
        {
            setremcost(prod[0].Rate - (prod[0].Discount * prod[0].Rate) / 100)
            var stock2 = [];
            if (prod[0].Stock > 10) {
                for (var x = 1; x <= 10; x++) {
                    stock2.push(x);//1-10
                }
            }
            else {
                for (var x = 1; x <= prod[0].Stock; x++) {
                    stock2.push(x);//1-5
                }
            }
            setstock(stock2);
        }
    }, [prod])

    useEffect(() => {
        settc(remcost * qty)
    }, [qty])

    async function fetchproductbyid() 
    {
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchproductbyid1?id=${prdid}`)
            // const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchproductbyid1?id=` + prdid)
           
            if (resp.data.statuscode === 1) 
            {
                setprod(resp.data.product)
            }
            else if (resp.data.statuscode === 0) 
            {
                setprod([])
            }
            else 
            {
                toast.warn("some problem occured")
            }
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
    }

    async function addtocart() {
        if(sessionStorage.getItem("userdata")===null)
        {
            toast.info("Please login to add to cart");
            navigate("/login");
        }   
        if(udata===null)
        {
            toast.info("Please login to add to cart");
            navigate("/login");
        } 
        else
        {
            const cartdata = {picture:prod.Picture , pname:prod.Name ,rate: remcost ,qty:qty , tc:tc , username:udata.username}
            try
            {
                const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/addtocart` , cartdata)
               
                if(resp.data.statuscode===1)
                {   
                    navigate("/showcart");
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warning("Problem while adding to cart, try again")
                }
                else
                {
                    toast.warn("some problem occured")
                }
            }
            catch(e)
            {
                toast.error("Error Occured " + e.message)
            }
        }
    }

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/homepage"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Product Details</li>
                    </ol>
                </div>
            </div>

            {/* beacuse mapping cannot be done for 0 index only */}
            {
                prod.length > 0 ?
                    <>
                        {
                            prod.map((item, index) =>
                                <div className="products" key={index}>
                                    <div className="container">
                                        <div className="agileinfo_single">

                                            <div className="col-md-4 agileinfo_single_left">
                                                <img id="example" src={`uploads/${item.Picture}`} alt=" " className="img-responsive" />
                                            </div>
                                            <div className="col-md-8 agileinfo_single_right">
                                                <h2>{item.Name}</h2>
                                                <div className="w3agile_description">
                                                    <h4>Description :</h4>
                                                    <p>{item.Description}</p>
                                                </div>
                                                <div className="snipcart-item block">
                                                    <div className="snipcart-thumb agileinfo_single_right_snipcart">
                                                        <h4 className="m-sing">₹{remcost}<span>₹{item.Rate}</span></h4>
                                                    </div>
                                                    {
                                                        item.Stock > 0 ?
                                                            <div className="snipcart-details agileinfo_single_right_details">
                                                                <form action="#" method="post">
                                                                    <fieldset>
                                                                        <select name="qty" className="form-control" onChange={(e) => setqty(e.target.value)}>
                                                                            <option value="">Choose Quantity</option>
                                                                            {
                                                                                stock.map((item, index) =>
                                                                                    <option key={index}>{item}</option>
                                                                                )
                                                                            }
                                                                        </select><br />
                                                                        <input type="button" name="submit" value="Add to cart" onClick={addtocart} className="button" />
                                                                    </fieldset>
                                                                </form>
                                                            </div> : <b>Out Of Stock</b>
                                                    }

                                                </div>
                                            </div>
                                            <div className="clearfix"> </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        }
                    </> : <h2>No product is Added By Admin</h2>
            }
        </>
    )
}
export default ProdDetails;