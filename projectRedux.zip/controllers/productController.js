const productmodel = require('../models/productModel');
const fs = require('fs');  

exports.fetchproductbycatidandsubcatid = async (req, res) => 
{
  try
  {
    const result = await productmodel.find({ catid: req.query.catid , subcatid: req.query.subcatid }).populate('catid').populate('subcatid')
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.addproduct = async (req, res) => 
{
  try
  {

    const mainImage = req.files["picture"]? req.files["picture"][0].filename : "noimage.jpg"
    const extraImage = req.files["extraimages"]? req.files["extraimages"].map(file => file.filename): []; // Keep .map where you need a new array (extraImage).

    const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
    const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
    const currentDateIST = new Date(currentDateUTC.getTime()+ ISTOffset)  // convert to IST

    const newrecord = new productmodel({ catid: req.body.catid, subcatid:req.body.subcatid ,Name: req.body.pname, Rate: req.body.rate, Discount: req.body.dis, Stock: req.body.stock, Description: req.body.descp, Picture: mainImage, ExtraPicture:extraImage  ,Addedon:currentDateIST })

    const result = await newrecord.save()
    if (result) 
    {
      res.send({ statuscode: 1 })
    }
    else
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.updateproduct= async (req, res) => 
{
  try
  {
    // ---------- PRIMARY IMAGE ----------
    var picturename;
    if (!req.files["pic"]) 
    {
      picturename = req.body.oldpicname; // keep old one
    }
    else 
    {
      picturename = req.files["pic"][0].filename;  // new upload

      if (req.body.oldpicname !== "noimage.jpg") 
      {
        fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
      }
    
    }

    // ---------- EXTRA IMAGES ----------

    let extraImage;
    if (!req.files["extraimages"]) 
    {
      // if no new images selected → keep old ones
      extraImage = req.body.oldextrapicname ? req.body.oldextrapicname : [];;
    } 
    else 
    {
      // replace with new uploads
     extraImage = req.files["extraimages"]? req.files["extraimages"].map(file=> file.filename): []; // Keep .map where you need a new array (extraImage).

      // delete old extra images if provided
      if (req.body.oldextrapicname) 
      {
        req.body.oldextrapicname.forEach(img => {   // Keep .forEach where you just need side effects (delete files).
          if (img !== "noimage.jpg") {
            fs.unlinkSync(`public/uploads/${img}`);
          }
        });
      }
    }

    const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
    const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
    const currentDateIST = new Date(currentDateUTC.getTime()+ ISTOffset)  // convert to IST

    const updateresult = await productmodel.updateOne({ _id: req.body.productid }, { $set: { catid: req.body.catid, subcatid:req.body.subcatid ,Name: req.body.upname, Rate: req.body.uprate, Discount: req.body.updis, Stock: req.body.upstock, Description: req.body.updescp, Picture: picturename ,ExtraPicture:extraImage ,Addedon:currentDateIST} });

    if (updateresult.modifiedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.delproduct = async (req, res) =>
{
  try
  {
    const result = await productmodel.deleteOne({ _id: req.query.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1, msg: "product deleted statuscodefully" })
    }
    else 
    {
      res.send({ statuscode: 0, msg: "product not deleted" })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.fetchprodbysubcatid = async (req, res) => 
{
  try
  {
    const result = await productmodel.find({ subcatid: req.query.subid }).populate('catid').populate('subcatid')
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.fetchproductbyid = async (req, res) => 
{
  try
  {
    const result = await productmodel.findOne({ _id: req.query.id })
    if (result===null) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, product: result})
      // res.send({ statuscode: 1, product: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.fetchproductbyid1 = async (req, res) => 
{
  try
  {
    const result = await productmodel.find({ _id: req.query.id })
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, product: result})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.fetchlatestprods = async (req, res) => 
{
  try
  {
    const result = await productmodel.find().sort({"Addedon":-1}).limit(6)
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.updatestock = async(req,res)=>
{
  try
  {
    const cartdata = req.body.cartinfo;
    for(var x=0;x<cartdata.length;x++)
    {
      var updateresult = await productmodel.updateOne({_id: cartdata[x].pid}, {$inc:{"Stock":-cartdata[x].Qty}});
      // In MongoDB, $inc is an update operator that increments or decrements a numeric field by a given value.
    }
    if(updateresult.modifiedCount===1)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }
  }
  catch(e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  } 
}

exports.searchproducts = async(req,res)=>
{
  try
  {
    const searchtext = req.query.q;
    const result = await productmodel.find({Name: { $regex: '.*' + searchtext ,$options:'i' }})
    //result will become an array because find function returns an array
    if(result.length===0)
    {
      res.send({statuscode:0})
    }
    else
    {
      res.send({statuscode:1,proddata:result})
    }    
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.fetchlatestprods = async (req, res) => 
{
  try
  {
    const result = await productmodel.find().sort({"Addedon":-1}).limit(6)
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}