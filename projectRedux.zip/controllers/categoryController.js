const categoryModel = require("../models/categoryModel");

exports.savecategory =  async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = "noimage.jpg"
    }
    else 
    {
      picturename = req.file.filename
    }
    const newrecord = new categoryModel({ catname: req.body.cname, catpic: picturename })
    const result = await newrecord.save();
    if (result) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }

}


exports.getallcat = async (req, res) => 
{
  try
  {
    const result = await categoryModel.find()
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, categorydata: result })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.delcat = async (req, res) => 
{
  try
  {
    const result = await categoryModel.deleteOne({ _id: req.query.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1, msg: "Category Deleted Successfully" })
    }
    else 
    {
      res.send({ statuscode: 0, msg: "Category not Deleted" })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.updatecategory = async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = req.body.oldpicname;//it will save current picname in this constiable
    }
    else 
    {
      picturename = req.file.filename;

      if (req.body.oldpicname !== "noimage.jpg") 
      {
        fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
      }

    }

    const updateresult = await categoryModel.updateOne({ _id: req.body.cid }, { $set: { catname: req.body.upname, catpic: picturename } });

    if (updateresult.modifiedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}