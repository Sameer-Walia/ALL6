const restPassModel = require('../models/resetpasswordModel')
const SignupModel = require("../models/signupModel");
const {v4: uuidv4} = require('uuid')  // to set unique id after signup where gmail link is open before login
const {sendMail} = require('../utils/mailer')
const bcrypt = require('bcrypt');

exports.forgotpassword = async (req, res) => 
{
  try 
  {
    const result = await SignupModel.findOne({ username: req.query.un })
    console.log(result)
    if(result===null)
    {
      res.send({ statuscode: 3 })
    }
    else
    {
      const passtoken = uuidv4();

      const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
      const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
      const fifteenminOffset = 15 * 60 * 1000; // IST offset in milliseconds (15 minutes)
      const expiretime = new Date(currentDateUTC.getTime()+ ISTOffset +  fifteenminOffset )  // add 15 min more

      const newrecord = new restPassModel({username:req.query.un , exptime:expiretime , token:passtoken })
      const result2 = newrecord.save()
      if(result2)
      {
        const mailOptions = {
          from: 'class@gtbinstitute.com', // transporter username email
          to: req.query.un,             // user's email id
          subject: 'Reset Password Mail from SuperMarket.com',
          html: `Dear ${result.pname}<br/><br/>Click on the Following Link to Reset your Password :-.<br/><br/><a href='http://localhost:3000/resetpassword?code=${passtoken}'>Reset Password<a/>`
        };

        const mailresp = await sendMail(mailOptions);
        if(mailresp.success===true)
        {
            res.send({ statuscode: 1})
        }
        else
        {
            res.send({ statuscode: 2 })
        }

      }
      else
      {
        res.send({statuscode:0})
      }
       
    }
    
  } 
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.checktoken = async(req , res)=>
{
    const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
    const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
    const currtime = new Date(currentDateUTC.getTime()+ ISTOffset ) 
    console.log(currtime)

  try
  {
    const result = await restPassModel.findOne({token:req.query.token})
    console.log(result)
    {
      if(result===null)
      {
        res.send({statuscode:0})
      }
      else
      {
        if(currtime<result.exptime)   // 5:20 < 5:30
        {
          res.send({statuscode:1})
        }
        else
        {
          // delete Token after it get expired
          const result2 = await restPassModel.deleteOne({ token: req.query.token })  
          if (result2.deletedCount === 1) 
          {
            res.send({ statuscode:0 })
          }
          else 
          {
            res.send({ statuscode:2 })
          }
        }
      }  
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.resetpassword = async (req, res) => 
{
  try
  {
    const result = await restPassModel.findOne({ token: req.body.token })
    console.log(result)
    if(result===null)
    {
      res.send({ statuscode: 0 })
    }
    else
    {
      const encryp_newpass = bcrypt.hashSync(req.body.newpass , 10)
      const updatepass = await SignupModel.updateOne({ username: result.username }, { $set: { password:encryp_newpass } })
      if (updatepass.modifiedCount === 1) 
      {
        res.send({ statuscode: 1 })
      }
      else 
      {
        res.send({ statuscode: 0 })
      }
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}