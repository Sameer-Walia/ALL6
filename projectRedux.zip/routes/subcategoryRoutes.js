const express = require('express')
const router = express.Router();

const {verifyjsontoken , verifyadmin} = require('../utils/auth')
const upload = require('../utils/multerConfig')

const subcategoryController = require('../controllers/subcategoryController')


router.get("/fetchsubcatbycatid" , subcategoryController.fetchsubcatbycatid)
router.post("/addsubcategory" , verifyjsontoken , verifyadmin , upload.single('picture'), subcategoryController.addsubcategory)
router.put("/updatesubcategory" , verifyjsontoken , verifyadmin , upload.single('upsubpic'), subcategoryController.updatesubcategory)
router.delete("/delsubcat" , verifyjsontoken , verifyadmin , subcategoryController.delsubcat)


module.exports = router;
