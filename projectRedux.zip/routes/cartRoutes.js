const express = require('express')
const router = express.Router();

const cartControllers = require("../controllers/cartControllers");

const { verifyjsontoken, verifyadmin } = require("../utils/auth");
const upload = require('../utils/multerConfig')


router.post("/addtocart", verifyjsontoken, cartControllers.addtocart)
router.get("/getcart", verifyjsontoken, cartControllers.getcart)
router.delete("/delproduct/:id", cartControllers.delproduct)
router.delete("/deletecart", cartControllers.deletecart)


module.exports = router;
