const express = require('express')
const router = express.Router();

const {verifyjsontoken , verifyadmin} = require('../utils/auth')
const upload = require('../utils/multerConfig')

const categoryController  = require("../controllers/categoryController");

router.post("/savecategory" , verifyjsontoken , verifyadmin , upload.single('cpic'), categoryController.savecategory)
router.get("/getallcat" , categoryController.getallcat)
router.delete("/delcat" , verifyjsontoken , verifyadmin , categoryController.delcat)
router.put("/updatecategory" , verifyjsontoken , verifyadmin , upload.single('uppic') ,categoryController.updatecategory)

module.exports = router;
