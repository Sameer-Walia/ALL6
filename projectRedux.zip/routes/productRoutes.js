const express = require('express')
const router = express.Router();

const productController  = require("../controllers/productController");

const {verifyjsontoken , verifyadmin} = require("../utils/auth");
const upload = require('../utils/multerConfig')


router.get("/fetchproductbycatidandsubcatid" , verifyjsontoken , verifyadmin ,  productController.fetchproductbycatidandsubcatid)

router.post("/addproduct" , verifyjsontoken , verifyadmin ,  upload.fields([{name:"picture" , maxCount:1},{name:"extraimages"}]), productController.addproduct)

router.put("/updateproduct" , verifyjsontoken , verifyadmin ,  upload.fields([{name:"pic" , maxCount:1},{name:"extraimages"}]), productController.updateproduct)

router.delete("/delproduct" , verifyjsontoken , verifyadmin ,  productController.delproduct)

router.get("/fetchprodbysubcatid" ,  productController.fetchprodbysubcatid)

router.get("/fetchproductbyid" ,  productController.fetchproductbyid)

router.get("/fetchproductbyid1" ,  productController.fetchproductbyid1)

router.get("/fetchlatestprods" ,  productController.fetchlatestprods)

router.put("/updatestock" ,  productController.updatestock)

router.get("/searchproducts" ,  productController.searchproducts)

router.get("/fetchlatestprods" ,  productController.fetchlatestprods)


module.exports = router;
