const express = require('express')
const router = express.Router();

const signupController  = require("../controllers/signupController");

const {verifyjsontoken , verifyadmin} = require("../utils/auth");

router.post("/signup" , signupController.signup)
router.post("/resendmail" , signupController.resendmail)
router.put("/activateuseraccount" , signupController.activateuseraccount)
router.post("/login" , signupController.login)
router.post("/logout" , signupController.logout)
router.get("/searchuser" , verifyjsontoken , verifyadmin , signupController.searchuser)
router.get("/getallusers" , verifyjsontoken , verifyadmin , signupController.getallusers)
router.get("/fetchoneuser/:id" , verifyjsontoken , verifyadmin , signupController.fetchoneuser)
router.put("/updateoneuser" , verifyjsontoken , verifyadmin , signupController.updateoneuser)
router.delete("/deluser/:uid" , verifyjsontoken , verifyadmin , signupController.deluser)
router.put("/changepassword" , verifyjsontoken , signupController.changepassword)


// contact-us api  , here it has no model , message directly sent on email
router.post("/ContactUs" , signupController.ContactUs)


module.exports = router;
