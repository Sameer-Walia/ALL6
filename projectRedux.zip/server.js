const express = require('express')
const app = express()
const port = 9010
app.use(express.json());

const cors = require('cors')
app.use(cors({
  origin: "http://localhost:3001",
  credentials: true     // for cookie
}))

const bcrypt = require('bcrypt');

require('dotenv').config()

const { v4: uuidv4 } = require('uuid')

var jwt = require('jsonwebtoken');

const cookieParser = require("cookie-parser")
app.use(cookieParser());


const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/projectdb(MCRS)').then(() => console.log('Connected to MongoDB'));


const signupRoutes = require('./routes/signupRoutes');
app.use('/api', signupRoutes)

const categoryRoutes = require('./routes/categoryRoutes');
app.use('/api', categoryRoutes)

const subcategoryRoutes = require('./routes/subcategoryRoutes');
app.use('/api', subcategoryRoutes)

const productRoutes = require('./routes/productRoutes');
app.use('/api', productRoutes)

const cartRoutes = require('./routes/cartRoutes');
app.use('/api', cartRoutes)

const finalorderRoutes = require('./routes/finalorderRoutes');
app.use('/api', finalorderRoutes)

const resetpasswordRoutes = require('./routes/resetpasswordRoutes');
app.use('/api', resetpasswordRoutes)


app.listen(port, () =>
{
  console.log(`Server is running on port ${port}`)
})